from django.shortcuts import render
from django.views.generic import View, ListView
from.models import Student
class Viewalldetails(View):
    def post(self,request):
        idno=request.POST.get("t1")
        name=request.POST.get("t2")
        clas=request.POST.get("t3")
        s=Student(idno=idno,name=name,clas=clas)
        s.save()
        return render(request,"index.html",{"mess":"saved"})
class Allstudents(ListView):
    model = Student
    template_name = "view.html"
