from django.shortcuts import render
from django.views.generic import ListView
from .models import Student


class studentdetails(ListView):
    model = Student
    queryset = Student.objects.values('idno')
    template_name = "details.html"

