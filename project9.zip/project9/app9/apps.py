from django.apps import AppConfig


class App9Config(AppConfig):
    name = 'app9'
