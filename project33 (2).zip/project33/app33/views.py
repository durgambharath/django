from django.shortcuts import render
from requests import request

from.forms import Registration
from.models import Newregistration
from django.views.generic import CreateView, FormView


class Newregister(FormView):
    form_class=Registration

    template_name = "index.html"

def save(request):
    name= request.POST.get("name")
    contact= request.POST.get("contact")
    age= request.POST.get("age")
    email= request.POST.get("email")
    password= request.POST.get("password")
    d=Registration()
    p=Newregistration(name=name,contact=contact,age=age,email=email,password=password)
    p.save()
    s=Newregistration.objects.all()
    return render(request,"index.html",{'form':d,'s':s})

def delete(request):
    name=request.POST.get("delete_id")
    print(name)
    d = Registration()
    res=Newregistration.objects.get(contact=name).delete()
    s=Newregistration.objects.all()
    return render(request,"index.html",{"delete":res,'form':d,"s":s})
