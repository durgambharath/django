from django.shortcuts import render
from django.views.generic import ListView
from django.views.generic import DetailView

from.models import Employee

class Employeedetails(ListView):
    model = Employee
    queryset = Employee.objects.values('id','name')
    template_name = "all_emp.html"


class Empdetails(DetailView):
    model = Employee
    template_name = "emp.html"
