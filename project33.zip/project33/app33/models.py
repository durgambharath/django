from django.db import models

class Newregistration (models.Model):
    name=models.CharField(max_length=50)
    contact= models.IntegerField(primary_key=True)
    age=models.IntegerField()
    email=models.EmailField(max_length=50)
    password=models.CharField(max_length=20)