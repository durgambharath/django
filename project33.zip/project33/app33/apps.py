from django.apps import AppConfig


class App33Config(AppConfig):
    name = 'app33'
