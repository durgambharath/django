from django import forms

class Registration(forms.Form):
    name=forms.CharField()
    contact= forms.IntegerField()
    age=forms.IntegerField()
    email=forms.EmailField()
    password=forms.CharField(label="password",widget=forms.PasswordInput)