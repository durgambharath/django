from django.apps import AppConfig


class App35Config(AppConfig):
    name = 'app35'
