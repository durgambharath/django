from django.shortcuts import render
from django.views.generic import ListView
from django.views.generic import DeleteView

from.models import Student
class StudentDetails(ListView):
    model = Student
    template_name = "index.html"

class DeleteDetails(DeleteView):
    model = Student
    template_name = "index.html"
    success_url='/std_deleted/'



