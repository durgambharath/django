from django.shortcuts import render
from django.views.generic import ListView
from django.views.generic import DeleteView
from django.views.generic import UpdateView

from.models import Student
class StudentDetails(ListView):
    model = Student
    template_name = "index.html"

class DeleteDetails(DeleteView):
    model = Student
    template_name = "index.html"
    success_url='/std_deleted/'


class Updatedetails(UpdateView):
    model = Student
    fields = ('name','age')
    template_name = "sd_details.html"

def details(request):
    name=request.POST.get("name")
    age=request.POST.get("age")
    p=Student(name=name,age=age)
    p.save()
    s=Student.objects.all()
    return render(request,"index.html",{'s':s})
